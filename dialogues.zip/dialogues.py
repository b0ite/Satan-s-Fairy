import pygame, math
from needed import *

class Dialogue:
    def __init__(self, screen, font_path, font_size=32, background_opacity=128):
        self.screen = screen
        self.dialogue_font = pygame.font.Font(font_path, font_size)
        self.name_font = pygame.font.Font(font_path, 25)
        self.choice_font = pygame.font.Font(font_path, 50)
        self.dialogues = {}
        self.current_dialogue = None
        self.dialogue_index = 0
        self.background_opacity = background_opacity
        self.active = False
        self.animation_offset = 0  # Décalage initial pour l'animation
        self.animation_direction = 0.3  # Direction de l'animation
        self.selected_choice = 0  # Index of the selected choice
        self.triggered_event = None

    def add_dialogue(self, key, dialogues):
        self.dialogues[key] = dialogues

    def trigger_dialogue(self, key):
        if key in self.dialogues:
            self.current_dialogue = self.dialogues[key]
            self.dialogue_index = 0
            self.active = True
            self.update_choices()

    def draw(self):
        if not self.active or not self.current_dialogue:
            return
        
        # Mise à jour du décalage d'animation
        self.animation_offset += self.animation_direction * 2  # Vitesse de l'animation
        if abs(self.animation_offset) > 10:  # Amplitude de l'animation
            self.animation_direction *= -1  # Inverser la direction à l'amplitude max/min
        
        background = pygame.Surface((self.screen.get_width(), self.screen.get_height()))
        background.set_alpha(self.background_opacity)
        background.fill((0, 0, 0))
        self.screen.blit(background, (0, 0))

        # Current step in dialogue
        step = self.current_dialogue[self.dialogue_index]
        
        # Checking if the current step has choices
        if isinstance(step, dict) and 'choices' in step:
            # Draw choices
            choice_height = 550  # Starting height for choices
            for idx, choice in enumerate(step['choices']):
                color = (255, 0, 0) if idx == self.selected_choice else (255, 255, 255)
                choice_text = self.choice_font.render(choice['text'], True, color)
                self.screen.blit(choice_text, (100, choice_height))
                choice_height += 50  # Increment to position next choice below
        else:
            # Process normal dialogue entries
            dialogue_rect = pygame.Rect(50, self.screen.get_height() - 150, self.screen.get_width() - 100, 100)
            name_rect = pygame.Rect(50, self.screen.get_height() - 200, self.screen.get_width() - 100, 50)
            
            for character in step:
                character_name, portrait, dialogue, position, is_speaking = character
                positions = {
                    'left': (50, self.screen.get_height() - portrait.get_height() - 100),
                    'center': (self.screen.get_width() // 2 - portrait.get_width() // 2, self.screen.get_height() - portrait.get_height() - 100),
                    'right': (self.screen.get_width() - portrait.get_width() - 50, self.screen.get_height() - portrait.get_height() - 100)
                }
                if is_speaking:
                    # Apply animation to the character who is speaking
                    adjusted_position = (positions[position][0], positions[position][1] + self.animation_offset)
                else:
                    adjusted_position = positions[position]
                
                portrait_rect = portrait.get_rect(topleft=adjusted_position)
                self.screen.blit(portrait, portrait_rect)
                
                if is_speaking:
                    # Draw name background and text
                    name_text = self.name_font.render(character_name, True, (255, 255, 255))
                    name_background_rect = name_text.get_rect(x=adjusted_position[0], y=adjusted_position[1] - 30)
                    name_background_rect.inflate_ip(20, 10)  # Expand the rectangle for aesthetics
                    pygame.draw.rect(self.screen, (0, 0, 0), name_background_rect)  # Black background for readability
                    self.screen.blit(name_text, name_background_rect.topleft)

                    pygame.draw.rect(self.screen, (255, 255, 255), dialogue_rect)
                    wrapped_text = self.wrap_text(dialogue, self.dialogue_font, dialogue_rect.width)
                    self.draw_text(wrapped_text, self.dialogue_font, (0, 0, 0), self.screen, dialogue_rect.x + 10, dialogue_rect.y + 10)

    def handle_event(self, event):
        if self.active:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if self.choices:
                        self.make_choice()
                    elif self.dialogue_index < len(self.current_dialogue) - 1:
                        self.dialogue_index += 1
                        self.update_choices()
                    else:
                        self.active = False  # End the dialogue sequence
                elif event.key == pygame.K_UP:
                    self.selected_choice = (self.selected_choice - 1) % len(self.choices)
                elif event.key == pygame.K_DOWN:
                    self.selected_choice = (self.selected_choice + 1) % len(self.choices)

    def make_choice(self):
        chosen_option = self.choices[self.selected_choice]
        next_step = chosen_option['next']
        self.trigger_dialogue(next_step)  # Continue with the next part of the dialogue

        # Check if the chosen option has an associated event to trigger
        if 'event' in chosen_option:
            self.triggered_event = chosen_option['event']
    
    def reset_triggered_event(self):
        self.triggered_event = None

    def wrap_text(self, text, font, max_width):
        words = text.split(' ')
        wrapped_lines = []
        current_line = ""
        for word in words:
            test_line = current_line + word + " "
            if font.size(test_line)[0] < max_width:
                current_line = test_line
            else:
                wrapped_lines.append(current_line)
                current_line = word + " "
        wrapped_lines.append(current_line)
        return wrapped_lines

    def draw_text(self, text, font, color, surface, x, y):
        for line in text:
            text_surface = font.render(line, True, color)
            surface.blit(text_surface, (x, y))
            y += font.get_linesize()
    
    def update_choices(self):
        # Get the current dialogue step
        step = self.current_dialogue[self.dialogue_index]

        # Check if the current step is a dictionary and has 'choices'
        if isinstance(step, dict) and 'choices' in step:
            self.choices = step['choices']
        else:
            self.choices = None  # No choices available in this step





def scale_image(img, target_width):
    """ Scale image to target width while maintaining aspect ratio. """
    width, height = img.get_size()
    scaling_factor = target_width / width
    new_height = int(height * scaling_factor)
    return pygame.transform.scale(img, (target_width, new_height))

def adapt_scale(img):
    global h, w
    base_img_width = img.get_width()
    scale_ratio = w / 1920
    new_width = int(base_img_width * scale_ratio)
    return scale_image(img, new_width)


pygame.init()
pygame.mixer.init()

player_name = "Jeanne"
#initialisation des images
père = pygame.image.load('./assets/personnages/pere.png').convert_alpha()
mère = pygame.image.load('./assets/personnages/mere.png').convert_alpha()
player = pygame.image.load('./assets/personnages/fille.png').convert_alpha()
detective = pygame.image.load('./assets/personnages/detective.png').convert_alpha()

père = adapt_scale(père)
mère = adapt_scale(mère)
player = adapt_scale(player)
detective = adapt_scale(detective)

print("images initialisées")

# Initialize the Dialogue system
dialogue_system = Dialogue(SCREEN, "./assets/Helvetica.ttf", 24)
# Setup dialogues
'''dialogue_system.add_dialogue("clée de dialogue", [
    #un seul personnage
    [("nom",image, "texte", #position sur l'ecran : 'left', 'center', 'right' , True)],#si un seul personnage parle
    #plusieurs personnages affichés en meme temps
    [("nom2",image, "", "center", False), #ne parle pas
    ("nom3",image, "", "right", False), #ne parle pas
    ("nom",image, "texte", "left", True)],#parle
    {'choices': [
        {'text': "text on the button", 'next': "name of the dialogue to go"},
        {'text': "==", 'next': "=="},
        {'text': "==", 'next': "=="}
    ]}
    ])
'''

#intro=================================================================================================================
dialogue_system.add_dialogue("intro", [
    [("Maman", mère, "", "right", False),
     ("Papa", père, "Où étais-tu passée, espèce de bonne à rien ?!", "left", True)
     ],
    [("Papa", père, "", "left", False),
     ("Maman", mère, "Je t'en prie, arrête... Je ne sais pas de quoi tu parles... Je...", "right", True)
     ],
    [("Maman", mère, "", "right", False),
     ("Papa", père, "Tu oses me mentir ?! Tu crois que je suis stupide ?!", "left", True)
     ],
    [("Moi", player, "*Les cris de maman résonnent dans ma tête comme des éclairs de douleur. Je ne peux plus supporter de voir papa la frapper ainsi. Ça me déchire à chaque fois...*", "center", True)
    ],
    [("Maman", mère, "", "right", False),
     ("Papa", père, "Tu vas regretter de m'avoir menti, salope !", "left", True)
     ],
    [("Moi", player, "*Mon cœur bat la chamade, ma respiration est saccadée. Je ne peux plus rester ici, à regarder maman souffrir. Chaque cri est un coup de poignard pour moi aussi.*", "center", True)
     ],
    [("Papa", père, "", "left", False),
     ("Maman", mère, "Arrête, s'il te plaît... Je t'en supplie... Ça suffit...", "right", True)
     ],
    [("Maman", mère, "", "right", False),
     ("Papa", père, "Tais-toi ! Tu ne mérites même pas de parler !", "left", True)
    ],
    [("Moi", player, "*Je dois partir, maintenant. Je ne peux plus supporter cela. Maman ne méritait pas ça, et moi non plus. Je dois trouver un endroit où je serais en sécurité, rester ici signifierais finir comme elle. Battue à mort injustement par un ivrogne dépourvu de coeur...*", "center", True)
     ],
    [("Moi", player, "*Peut-être dehors, je pourrais respirer, penser, fuir tout ça...*", "center", True)
     ],
    [("Papa", père, f"Reviens ici immédiatement ! {player_name} !", "center", True),
     ],
    [("Moi", player, "*Non, je ne veux pas revenir en arrière. Pas cette fois.*", "center", True)
     ]
    ])

#détective=============================================================================================================
dialogue_system.add_dialogue("detective avec pistolet",[
    [("Inconnu",detective, "Bonsoir, jeune dame. J'aimerais parler avec toi un instant, si tu le permets. Ton père est à ta recherche.", "center", True)],
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Je ne veux rien savoir de lui. Pourquoi m'enverrait-il quelqu'un si tout ce qu'il sait faire c'est hurler et blesser ?", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "Je comprends ta réticence, vraiment. Mais je ne suis pas là pour discuter  ou même réfléchir à la moralité et à la portée de mes actions de mes actions, vois-tu comme toi je ne cherche qu’à survivre. Enfin bref, ton père veut te récupérer et moi je veux être payé.", "right", True)
    ],
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Tu penses sérieusement que je vais accepter de venir avec toi, de retourner auprès de lui après ce qu’il a fait à maman ?", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "J’en suis sûr, qu’importe ce qu’il ait fait, il reste ton père et il peut te protéger, tu penses que ce monde, que ces rues sont mieux que lui. Tout est pareil, partout où tu vas la violence, la haine et la peine sont présentes. Ton père peut t’offrir un toit sur la tête et même a manger dans ton assiette, alors si tu veux survivre tu ferais mieux de m’écouter. De toute façon tu finiras bien par y retourner de gré ou de force.", "right", True)
    ],
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Jamais je n’y retournerais, je préférerais mourir plutôt que de retourner vivre avec lui, une vie à ses côté est pire que la mort. Je l’ai compris grâce à maman.", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "Tu as plus peur de ton père que de la mort ? C’est compréhensible cependant ce n’est pas le cas de tout le monde et tu dois vivre, parce que la vie est don que ta mère t’as fait, ne gâche pas ça, si tu ne veux pas vivre pour toi, vis pour elle.", "right", True)
    ],
    {'choices': [
        {'text': "Fuir", 'next': "fuir  detective", 'event': "fuite_det"},
        {'text': "Rentrer", 'next': "rentrer_det", 'event': "rentrer_det"},
        {'text': "Donner la peluche", 'next': "don peluche", 'event' : "peluche"},
        {'text': "L'attaquer", 'next': "tuer det", 'event' : "pistolet"}
    ]}
    ])

dialogue_system.add_dialogue("detective sans pistolet",[
    [("Inconnu",detective, "Bonsoir, jeune dame. J'aimerais parler avec toi un instant, si tu le permets. Ton père est à ta recherche.", "center", True)],
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Je ne veux rien savoir de lui. Pourquoi m'enverrait-il quelqu'un si tout ce qu'il sait faire c'est hurler et blesser ?", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "Je comprends ta réticence, vraiment. Mais je ne suis pas là pour discuter  ou même réfléchir à la moralité et à la portée de mes actions de mes actions, vois-tu comme toi je ne cherche qu’à survivre. Enfin bref, ton père veut te récupérer et moi je veux être payé.", "right", True)
    ],
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Tu penses sérieusement que je vais accepter de venir avec toi, de retourner auprès de lui après ce qu’il a fait à maman ?", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "J’en suis sûr, qu’importe ce qu’il ait fait, il reste ton père et il peut te protéger, tu penses que ce monde, que ces rues sont mieux que lui. Tout est pareil, partout où tu vas la violence, la haine et la peine sont présentes. Ton père peut t’offrir un toit sur la tête et même a manger dans ton assiette, alors si tu veux survivre tu ferais mieux de m’écouter. De toute façon tu finiras bien par y retourner de gré ou de force.", "right", True)
    ],
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Jamais je n’y retournerais, je préférerais mourir plutôt que de retourner vivre avec lui, une vie à ses côté est pire que la mort. Je l’ai compris grâce à maman.", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "Tu as plus peur de ton père que de la mort ? C’est compréhensible cependant ce n’est pas le cas de tout le monde et tu dois vivre, parce que la vie est don que ta mère t’as fait, ne gâche pas ça, si tu ne veux pas vivre pour toi, vis pour elle.", "right", True)
    ],
    {'choices': [
        {'text': "Fuir", 'next': "fuir detective", 'event': "fuite_det"},
        {'text': "Rentrer", 'next': "rentrer_det", 'event': "rentrer"},
        {'text': "Donner la peluche", 'next': "don peluche", 'event' : "peluche"}
    ]}
    ])

dialogue_system.add_dialogue("fuir detective",[
    [("Détective",detective, "", "right", False),
    ("Moi",player, "*Non, je ne peux pas retourner en arrière, pas après tout ce qui s’est passé.*", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "Attend petite ! Reviens là, tu ne peux pas survivre seule dehors !..", "right", True)
    ]
])

dialogue_system.add_dialogue("rentrer_det",[
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Disons que je décide de vous faire confiance, que se passera-t-il ? Je rentre, et ensuite ?", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "Eh bien c’est une sage décision tu n’as plus qu’’à me suivre et je te ramène chez toi.", "right", True)
    ]
])

dialogue_system.add_dialogue("don peluche",[
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Vous voulez vraiment m’aider ? Montrez-lui ça et dites-lui que vous m'avez trouvée et que je suis morte.", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "Je... Je peux essayer. Mais Jeanne, ton père pourrait vouloir voir ton corps.", "right", True)
    ],
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Vous n’avez qu’à vous débrouillez avec ça. Je ne compte pas retourner là-bas, alors soit vous faites ça, soit vous me tuez sur le champ et vous amenez mon cadavre à mon père mais je ne crois pas que ce soit pour cela qu’il vous paye.", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "Bien je vais essayer. Sois prudente pour la suite.", "right", True)
    ]
])

dialogue_system.add_dialogue("tuer det",[
    [("Détective",detective, "", "right", False),
    ("Moi",player, "Laisse moi tranquille !", "left", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "Attend petite qu'est ce que tu fais ?! Attend ne fais pas ç...", "right", True)
    ],
    [("Moi", player, "", "left", False),
     ("Détective", detective, "", "right", False)
    ]
])

#Pistolet===========================================================================================================
dialogue_system.add_dialogue("Le player trouve le pistolet", [
    [("Moi", player, "La nuit avait enveloppé la ville de son manteau sombre, mais même dans l'obscurité, la violence et la mort semblaient rôder dans chaque coin de rue. Je marchais d'un pas déterminé, mes sens en alerte, mes pensées comme des lames aiguisées dans mon esprit.", "center", True)],
    [("Moi", player, "Mon instinct me disait de fuir, de ne pas m'approcher de cette scène sinistre. Mais la curiosité et un soupçon de cynisme m'incitaient à avancer, à découvrir ce qui se cachait dans l'obscurité.", "center", True)],
    [("Moi", player, "Un pistolet. Comme si la ville n'était pas déjà assez remplie de violence et de mort. Je pourrais presque entendre le rire amer de l'ironie alors que je contemplais cette scène macabre.", "center", True)],
    [("Moi", player, "Mais peut-être que ce pistolet pourrait être utile. Peut-être que dans ce monde impitoyable, je serais plus en sécurité avec une arme entre mes mains qu'avec la simple innocence d'une enfant perdue dans les ténèbres.", "center", True)],
    {'choices': [
        {'text': "Prendre le pistolet", 'next': "prendre", 'event': "pistolet"},
        {'text': "Refuser de prendre le pistolet", 'next': "pas_prendre"},
        {'text': "Se suicider", 'next': "suicide"}
    ]}
])

dialogue_system.add_dialogue("suicide", [
    [("Moi", player, "Plus rien ne m’attend dans cette vie, il ne reste que la misère, la souffrance et la peine. Plus jamais je ne serais capable de sourire, je ne rêve plus du bonheur, je ne rêve plus que de la tranquillité. L’espoir à laissé place à une abîme, à un monstre qui me ronge et me blesse de l’intérieur. Il n’y a plus qu’un solution, attends moi maman j’arrive.", "center", True)],
])

dialogue_system.add_dialogue("pas_prendre", [
    [("Moi", player, "Non. Je ne vais pas tomber dans cette spirale de violence. Je refuse de devenir comme eux. Céder à la violence reviendrait à légitimer les actes et le comportement de mon père.", "center", True)],
    [("Moi", player, "Non, je ne peux pas. Ce n'est pas la solution. Je ne veux pas devenir une part de cette obscurité.", "center", True)],
    [("Moi", player, "Je trouverai un moyen. Je ne vais pas céder à la peur et à la violence. Je suis plus forte que ça.", "center", True)]
])



dialogue_system.add_dialogue("prendre", [
    [("Moi", player, "Il n’y a qu’avec ça que je pourrais garantir ma sécurité, mon père est horrible mais il est à l’image du monde dans lequel nous vivons. Si je veux vivre je dois être forte, plus que la violence. Cette arme me donneras la force de défier la mort et la peur.", "center", True)],
])

#Truands avec pistolet___________________________________________________________________________________________________________________
dialogue_system.add_dialogue("Rencontre avec les truands(pistolet)",[
    [("Truand 1", Truand_1, "", "right", False),
     ("Truand 2", Truand_2, "", "center", False),
     ("Moi", player, "...", "left", True)],
    {'choices': [
        {'text': "Ignorer", 'next': "Inaction agression"},
        {'text': "Tirer", 'next': "Tir sur truand"},
        {'text': "Intervenir diplomatiquement", 'next': "Intervention diplomatique"}
    ]}
])
#Si le player n'interviens pas
dialogue_system.add_dialogue("Inaction agression",[
    [("Moi", player, "Ce que je vois est terrifiant... mais intervenir pourrait me coûter la vie. Parfois, survivre signifie ignorer les horreurs devant nous. Je dois penser à ma sécurité avant tout.", "center", True)]
])
#Si le player tir
dialogue_system.add_dialogue("Tir sur truand",[
    [("Truand 1", Truand_1, "", "right", False),
     ("Truand 2", Truand_2, "", "center", False),
    ("Moi", player, "Laissez-le partir !", "left", True)],
    {'choices': [
        {'text': "Menacer l'autre truand", 'next': "Menace Truand", 'event': "Fin_3"},
        {'text': "Fuir", 'next': "Fuite après tir", 'event': "Truands"},
    ]}
])
#si le joueur menace l'autre truand
dialogue_system.add_dialogue("Menace Truand",[
    [("Truand 1", Truand_1, "", "right", False),
    ("Moi", player, "Ne bouge pas !", "left", True)]
    [("Moi", player, "", "center", False),
     ("Truand 1", Truand_1, "Tu crois vraiment que tu peux nous arrêter avec ça ?", "right", True)]
     [("Moi", player, "", "center", False),
     ("Truand 1", Truand_1, "Tu vas payer pour ce que tu as fait, aucune souffrance, aucun effort ne pourront réparer ce que tu as fait ", "right", True)]
])#Lancer la fin_3

#Si le joueur s'enfuit après avoir tiré
dialogue_system.add_dialogue("Fuite après tir",[
    [("Moi", player, "Je dois m'échapper tant que je le peux encore !", "center", True)]
])

#Si le joueur choisit la voie diplomatique
dialogue_system.add_dialogue("Intervention diplomatique",[
    [("Truand 1", Truand_1, "", "right", False),
    ("Truand 2", Truand_2, "", "center", False),
    ("Moi", player, "Arrêtez ça ! Vous n'avez pas besoin de faire du mal à quelqu'un pour prouver votre force. ", "left", True)],
    [("Moi", player, "", "left", False),
    ("Truand 2", Truand_2, "", "center", False),
    ("Truand 1", Truand_1, "T’en as dans le froc pour nous interrompre", "right", True)],
    [("Moi", player, "", "left", False),
    ("Truand 1", Truand_1, "", "right", False),
    ("Truand 2", Truand_2, "Tu a l’air de fuir quelque chose, faisons un deal : Tu dépouille et tu frappe ce morveux puis tu pourras nous rejoindre.", "center", True)],
    [("Moi", player, "", "left", False),
    ("Truand 2", Truand_2, "", "center", False),
    ("Truand 1", Truand_1, "On te promet pas la richesse ni le bonheur, mais avec nous tu seras en sécurité et tu ne manqueras de rien tant que tu nous aideras. Ici-bas le bonheur est un luxe que peu de gens peuvent s’offrir, mais la sécurité, ça c’est un question de groupe et de nombre. Rejoins nous et tu n’auras plus jamais peur.", "right", True)],
    {'choices': [
        {'text': "Partir", 'next': "Partir echec diplomatie", 'event': "Truands"},
        {'text': "Faire ce qu'ils demandent", 'next': "agression enfant", 'event': "Fin_6"},
        {'text': "La diplomatie a échoué, place au sang", 'next': "Tir sur truand"}
    ]}
])
#Si le Joueur Part
dialogue_system.add_dialogue("Fuite après tir",[
    [("Moi", player, "Rien de bon ne sortira de ce marché. Je ferais mieux de partir.", "center", True)]
])
#Si le joueur agresse l'enfant
dialogue_system.add_dialogue("agression enfant",[
    [("Truand 1", Truand_1, "", "right", False),
    ("Truand 2", Truand_2, "", "center", False),
    ("Moi", player, "il faut que j’accepte, tout vaut mieux que de retourner vivre avec papa. Ils ont raison, la sécurité à un prix et je ne veux plus errer sans but et dans la peur de la mort à chaque croisement.", "left", True)],
    [("Truand 1", Truand_1, "", "right", False),
    ("Truand 2", Truand_2, "", "center", False),
    ("Moi", player, "Très bien j’accepte", "left", True)],
    [("Moi", player, "", "left", False),
    ("Truand 2", Truand_2, "", "center", False),
    ("Truand 1", Truand_1, "Bienvenue dans la bande. Tu es des nôtres maintenant. ", "right", True)],
])
#Truands sans pistolet___________________________________________________________________________________________________________________
dialogue_system.add_dialogue("Rencontre avec les truands(sans pistolet)",[
    [("Truand 1", Truand_1, "", "right", False),
     ("Truand 2", Truand_2, "", "center", False),
     ("Moi", player, "...", "left", True)],
    {'choices': [
        {'text': "Ignorer", 'next': "Inaction agression"},
        {'text': "Intervenir diplomatiquement", 'next': "Intervention diplomatique"}
    ]}
])

dialogue_system.add_dialogue("Intervention diplomatique (sans pistolet)",[
    [("Truand 1", Truand_1, "", "right", False),
    ("Truand 2", Truand_2, "", "center", False),
    ("Moi", player, "Arrêtez ça ! Vous n'avez pas besoin de faire du mal à quelqu'un pour prouver votre force. ", "left", True)],
    [("Moi", player, "", "left", False),
    ("Truand 2", Truand_2, "", "center", False),
    ("Truand 1", Truand_1, "T’en as dans le froc pour nous interrompre", "right", True)],
    [("Moi", player, "", "left", False),
    ("Truand 1", Truand_1, "", "right", False),
    ("Truand 2", Truand_2, "Tu a l’air de fuir quelque chose, faisons un deal : Tu dépouille et tu frappe ce morveux puis tu pourras nous rejoindre.", "center", True)],
    [("Moi", player, "", "left", False),
    ("Truand 2", Truand_2, "", "center", False),
    ("Truand 1", Truand_1, "On te promet pas la richesse ni le bonheur, mais avec nous tu seras en sécurité et tu ne manqueras de rien tant que tu nous aideras. Ici-bas le bonheur est un luxe que peu de gens peuvent s’offrir, mais la sécurité, ça c’est un question de groupe et de nombre. Rejoins nous et tu n’auras plus jamais peur.", "right", True)],
    {'choices': [
        {'text': "Partir", 'next': "Partir echec diplomatie", 'event': "Truands"},
        {'text': "Faire ce qu'ils demandent", 'next': "agression enfant", 'event': "Fin_6"},
    ]}
])

#les vieux_______________________________________________________________________________________________________________________
dialogue_system.add_dialogue("Rencontre avce les vieux (bon)",[
    [("Vieux", papy, "", "right", False),
    ("Vieille", mamie, "", "center", False),
    ("Moi", player, "...", "left", True)],
    {'choices': [
        {'text': "Demander de l'aide", 'next': "dialogue vieux", 'event': "Fin_4"},
        {'text': "Ne rien faire", 'next': "Inaction vieux", 'event': "vieux"},
    ]}
])

dialogue_system.add_dialogue("Rencontre avce les vieux (bon)",[
    [("Moi", player, "", "left", False),
    ("Vieux", papy, "", "right", False),
    ("Vieille", mamie, "Oh, ma petite, mais que t’est-il arrivé ? Tu es blessée ! Hugues nous devons l’aider.", "center", True),
    ]
    [("Moi", player, "", "left", False),
    ("Vieille", mamie, "", "center", False),
    ("Vieux", papy, "Et ton jouet est tout abîmé... Viens ici, voyons ce que nous pouvons faire pour toi.", "right", True),
    ]
    [("Moi", player, "", "left", False),
    ("Vieux", papy, "", "right", False),
    ("Vieille", mamie, "Qu'est-ce qui t'a amenée ici toute seule, chérie ? Tu as de la famille chez qui on pourrait t’amener ?", "center", True),
    ]
    [("Vieux", papy, "", "right", False),
    ("Vieille", mamie, "", "center", False),
    ("Moi", player, "J'en avait une", "left", True)
    ]
    [("Moi", player, "", "left", False),
    ("Vieille", mamie, "", "center", False),
    ("Vieux", papy, "Tu es en sécurité avec nous maintenant. Ne t’inquiète pas.", "right", True),
    ]
    [("Moi", player, "", "left", False),
    ("Vieux", papy, "", "right", False),
    ("Vieille", mamie, "Voilà, ton ami est presque comme neuf. Que dirais-tu de venir chez nous, on pourrait t’aider, tu pourras te rétablir puis on décideras quoi faire ensuite?", "center", True),
    ]
])

dialogue_system.add_dialogue("Inaction vieux",[
    [("Moi", player, "ça ne sers à rien, personne ne peu m'aider et tout le monde m'ignore", "left", True)],
])

dialogue_system.add_dialogue("Rencontre avce les vieux (pas bon)",[
    [("Vieux", papy, "", "right", False),
    ("Vieille", mamie, "", "center", False),
    ("Moi", player, "...", "left", True)],
    {'choices': [
        {'text': "Demander de l'aide", 'next': "dialogue vieux pas bon", 'event': "vieux"},
        {'text': "Ne rien faire", 'next': "Inaction vieux", 'event': "vieux"},
    ]}
])

dialogue_system.add_dialogue("dialogue vieux pas bon",[
    [("Vieux", papy, "", "right", False),
    ("Vieille", mamie, "", "center", False),
    ("Moi", player, "Bonjour... Puis-je...", "left", True)
    ]
    [("Moi", player, "", "left", False),
    ("Vieux", papy, "", "right", False),
    ("Vieille", mamie, "Voilà, ton ami est presque comme neuf. Que dirais-tu de venir chez nous, on pourrait t’aider, tu pourras te rétablir puis on décideras quoi faire ensuite?", "center", True),
    ]
    [("Moi", player, "", "left", False),
    ("Vieux", papy, "", "right", False),
    ("Vieille", mamie, "Nous ne pouvons rien pour toi, jeune fille. C’est triste de voir tant de jeunes dans la rue ces jours-ci.", "center", True),
    ]
    [("Moi", player, "", "left", False),
    ("Vieille", mamie, "", "center", False),
    ("Vieux", papy, "Que veux-tu c'est comme ça maintenant et puis ce n'est pas comme si on pouvait guérir la misère", "right", True),
    ]
    [("Moi", player, "Ils m'ont ignoré", "center", True)],
])

#le chien______________________________________________________________________________________________________________________________________
dialogue_system.add_dialogue("Rencontre avec chien (avec pistolet)",[
    [("Moi", player, "Qu'est-ce que...?.", "center", True)],
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "C'est bon, chien... je ne vais pas te faire de mal.", "left", True)],
    [("Moi", player, "", "left", False)
    ("Chien", s_chien, "Grrrrrrrh", "right", True)],
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "Non ! Arrête ça !", "left", True)],
    [("Moi", player, "", "left", False)
    ("Chien", s_chien, "Grrrrrrrh ouaf ouaf grrrrrrrrrrh", "right", True)],
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "Aïe ! Lâche ça, s'il te plaît !", "left", True)],
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "Oh non, pas ça... pourquoi ?", "left", True)],
    {'choices': [
        {'text': "Partir", 'next': "Partir chien", 'event': "blessée"},
        {'text': "Abattre le démon", 'next': "Tir sur chien", 'event': "pistochien"},
    ]}
])
#Si on tire:
dialogue_system.add_dialogue("Tir sur chien",[
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "Crève, crève, crève !!", "left", True)],
    [("Moi", player, "... Il est  temps de se remettre en route", "center", True)],
])
#Si on part:
dialogue_system.add_dialogue("Partir chien",[
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "Vite il faut que je parte", "left", True)],
])

#Chien sans pistolet
dialogue_system.add_dialogue("Rencontre avec chien (sans pistolet)",[
    [("Moi", player, "Qu'est-ce que...?.", "center", True)],
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "C'est bon, chien... je ne vais pas te faire de mal.", "left", True)],
    [("Moi", player, "", "left", False)
    ("Chien", s_chien, "Grrrrrrrh", "right", True)],
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "Non ! Arrête ça !", "left", True)],
    [("Moi", player, "", "left", False)
    ("Chien", s_chien, "Grrrrrrrh ouaf ouaf grrrrrrrrrrh", "right", True)],
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "Aïe ! Lâche ça, s'il te plaît !", "left", True)],
    [("Chien", s_chien, "", "right", False)
    ("Moi", player, "Oh non, pas ça... pourquoi ?", "left", True)],
    {'choices': [
        {'text': "Partir", 'next': "Partir chien", 'event': "blessée"},
    ]}
])

#le père================================================================================================================
dialogue_system.add_dialogue("papa",[
    [("Papa",père, f"Enfin, je t'ai trouvée. Il est temps de rentrer à la maison, {player_name}.", "center", True)
    ],
    [("Papa",père, "", "right", False),
    ("Moi",player, "Papa, je... je ne peux pas revenir. Pas après tout ce qui s'est passé.", "left", True)
    ],
    [("Moi",player, "", "left", False),
     ("Papa",père, "Tu penses que là dehors tu es chez toi, tu penses toucher la liberté. Laisse moi te dire une chose, la liberté ce n’est qu’un mot, un idéal bon pour les naïfs, combien de cadavres as-tu vu, combien de personne s’en prennent aux autres. Est-ce ça la liberté à laquelle tu aspires. Cesse tes enfantillages et retournons à la maison. Il n’y a pas d’autre endroit où tu seras acceptée, tu n’as pas d’autre endroit où te réfugier. Si tu refuses tu te condamne à mort et ta mère n’aurais pas voulu ça, elle ne voudrait pas que tu la rejoignes.", "right", True)
    ],
    [("Papa",père, "", "right", False),
    ("Moi",player, "Que sais-tu de ce que voulait maman ? A part les blessures que tu lui causé tu ne sais rien d’elle ?", "left", True)
    ],
    [("Moi",player, "", "left", False),
     ("Papa",père, "La seule chose que je sais d’elle, c’est qu’elle t’aimais et qu’elle est libre aujourd’hui, viens avec moi, je suis le seul souvenir que tu ais d’elle. ", "right", True)
    ],
    {'choices': [
        {'text': "Fuir", 'next': "fuir papa", 'event': "fuite_pap"},
        {'text': "Rentrer", 'next': "rentrer_pap", 'event': "rentrer"}
    ]}
    ])

dialogue_system.add_dialogue("rentrer_pap",[
    [("Papa",père, "", "right", False),
    ("Moi",player, "*Je ne peux survivre seule dehors, ça me fait mal mais j’ai besoin d’aide et puis je n’ai pas le choix si je ne veux pas mourir maintenant, si c’est pas lui, le monde se chargera de me tuer. Je dois vivre pour elle.*", "left", True)
    ],
    [("Moi",player, "", "left", False),
     ("Papa",père, "Bon tu te magnes ?", "right", True)
    ],
    [("Papa",père, "", "right", False),
    ("Moi",player, "*J’arrive...", "center", True)
    ]
])

dialogue_system.add_dialogue("fuir papa avec pistolet",[
    [("Papa",père, "", "right", False),
    ("Moi",player, "Non, je ne peux pas faire ça. Je ne peux plus vivre avec toi.", "left", True)
    ],
    [("Moi",player, "", "left", False),
     ("Papa",père, "Tu n'as pas le choix !", "center", True)
    ],
    [("Moi",player_wp, "", "left", False),
     ("Doudou",peluche, "", "center_left", False),
     ("Papa",père_couteau, "", "center", False)
    ],
    [("Moi",player_wp, "", "left", False),
     ("Doudou",peluche, "", "center_left", False),
     ("Papa",père_couteau, "Si tu ne viens pas de ton plein gré, je devrai prendre des mesures drastiques. Tu ne veux pas que je fasse du mal à ton seul ami, n'est-ce pas ?", "center", True)
    ],
    [("Papa",père_couteau, "", "center", False),
     ("Doudou",peluche, "", "center_left", False),
     ("Moi",player_wp, "Ne lui fais pas de mal, je t'en supplie...", "left", True)
    ],
    {'choices': [
        {'text': "Tuer", 'next': "tuer papa", 'event': "tuer_pap"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"}
    ]}
])

dialogue_system.add_dialogue("fuir papa sans pistolet",[
    [("Papa",père, "", "right", False),
    ("Moi",player, "Non, je ne peux pas faire ça. Je ne peux plus vivre avec toi.", "left", True)
    ],
    [("Moi",player, "", "left", False),
     ("Papa",père, "Tu n'as pas le choix !", "center", True)
    ],
    [("Moi",player_wp, "", "left", False),
     ("Doudou",peluche, "", "center_left", False),
     ("Papa",père_couteau, "", "center", False)
    ],
    [("Moi",player_wp, "", "left", False),
     ("Doudou",peluche, "", "center_left", False),
     ("Papa",père_couteau, "Si tu ne viens pas de ton plein gré, je devrai prendre des mesures drastiques. Tu ne veux pas que je fasse du mal à ton seul ami, n'est-ce pas ?", "center", True)
    ],
    [("Papa",père_couteau, "", "center", False),
     ("Doudou",peluche, "", "center_left", False),
     ("Moi",player_wp, "Ne lui fais pas de mal, je t'en supplie...", "left", True)
    ],
    {'choices': [
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"},
        {'text': "Rentrer", 'next': "rentrer_pap2", 'event': "rentrer"}
    ]}
])

dialogue_system.add_dialogue("tuer papa",[
    [("Papa",père_couteau, "", "center", False),
     ("Doudou",peluche, "", "center_left", False),
     ("Moi",player_pistolet, "Non, ça suffit. Ça s'arrête maintenant !", "left", True)
    ],
    [("Doudou",peluche, "", "center_left", False),
     ("Moi",player_pistolet, "", "left", False)
    ],
    [("Moi",player, "C'est fini... Je suis libre maintenant, maintenant maman est vengé, j’espère qu’elle est en paix en sachant que papa ne pourras plus faire de mal.", "left", True)
    ],
])

dialogue_system.add_dialogue("rentrer_pap2",[
    [("Papa",père_couteau, "", "center", False),
     ("Doudou",peluche, "", "center_left", False),
     ("Moi",player_wp, "D'accord, arrête ! Je vais rentrer avec toi. Ne lui fais pas de mal...", "left", True)
    ],
    [("Moi",player_wp, "", "left", False),
     ("Doudou",peluche, "", "center_left", False),
     ("Papa",père, "Sage décision. Allons-y.", "center", True)
    ],
    [("Moi",player, "", "left", False),
     ("Papa",père, "", "center", False)
    ]
])

current_dialogue_key = "intro"
dialogue_triggered = False